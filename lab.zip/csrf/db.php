<?php
$host = 'localhost';
$user = 'root';
$password = '';
$connect = mysqli_connect($host, $user, $password, 'sgi_lab');
?>