<?php
error_reporting(0);
session_start();
if($_SESSION['active_user'] != 'c81e728d9d4c2f636f067f89cc14862c'){
    header('Location:'.$_SESSION['HTTP_REFERER']);
}else{
    $file = $_GET['file'];
    $file_path=$file;
    $ctype="application/octet-stream";
    if(!empty($file_path) && file_exists($file_path)){ /*check keberadaan file*/
    header("Pragma:public");
    header("Expired:0");
    header("Cache-Control:must-revalidate");
    header("Content-Control:public");
    header("Content-Description: File Transfer");
    header("Content-Type: $ctype");
    header("Content-Disposition:attachment; filename=\"".basename($file_path)."\"");
    header("Content-Transfer-Encoding:binary");
    header("Content-Length:".filesize($file_path));
    flush();
    readfile($file_path);
    exit();
    }
}
?>