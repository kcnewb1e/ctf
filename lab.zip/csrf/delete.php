<?php
session_start();
if(isset($_POST['action'])){
    if($_POST['action'] == 'delete'){
        include 'db.php';
        $id = $_SESSION['active_user'];
        $delete = mysqli_query($connect, "DELETE FROM users WHERE id = '$id'");
        if($delete){
            session_destroy();
        }
    }
}
header("location: login.php");
?>