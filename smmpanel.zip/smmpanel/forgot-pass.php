<?php 
  header('Location: http://www.facebook.com/zidanvl18');
  exit;
?>