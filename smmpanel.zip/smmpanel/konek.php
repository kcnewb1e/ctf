<?php 

class koneksi{
    
protected $db;

function __construct(){
define('DB_NAME','smmpanel');
define('USER','root');
define('PASS','');
define('HOST','localhost');
$this->db = new mysqli(HOST,USER,PASS,DB_NAME) OR die('AUTH DB IS NOT VALIDED'); 
}


function querys($query){
return $this->db->query($query);
}

}
$db = new koneksi();